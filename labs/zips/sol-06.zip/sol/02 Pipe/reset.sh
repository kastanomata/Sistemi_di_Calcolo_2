#!/bin/bash
pkill -f main
